angular.module('3votApp').controller('MainCtrl', function ($scope) {
  $scope.awesomeThings = [ 'AngularJS', 'Grunt', 'Browserify' ];
});
