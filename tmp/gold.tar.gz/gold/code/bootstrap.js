
// Third party libraries/frameworks.
require('angular/angular');
require('angular-route/angular-route');


// Application resources.
require('./app');
require('./controllers/MainCtrl');
